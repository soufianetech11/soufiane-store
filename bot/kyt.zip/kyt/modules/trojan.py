from kyt import *

@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
  async def create_trojan_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Crate Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1)  + "▱" * ((3 - i) // 1) 
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{pw}" | /etc/shell/4'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("trojan://(.*)",a)]
      print(b)
      domain = re.search("@(.*?):",b[0]).group(1)
      uuid = re.search("trojan://(.*?)@",b[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**          ◇ TROJAN ACCOUNT ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{user}`
**» Host Domain  :** `{DOMAIN}`
**» User ID      :** `{uuid}`
**» Limit IP :** `{ip} IP`
**» port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `/trojan`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link TLS   : **
`{b[0]}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link NTLS    :** 
`{b[1].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{b[2].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account     :**
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━━━━━◇
**Expired Until :** `{later}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_trojan_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-trojan'))
async def cek_trojan(event):
  async def cek_trojan_(event):
    cmd = '/etc/shell/cek trojan'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**      ◇ LIST TROJAN ACCOUNT ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
{z}
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_trojan_(event)
  else:
    await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login-trojan'))
async def login_trojan(event):
  async def login_trojan_(event):
    cmd = '/etc/shell/loginx trojan'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""

{z}
**◇━━━━━━━━━━━━━━━━━━━━━◇**
""",buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_trojan_(event)
  else:
    await event.answer("Access Denied",alert=True) 

@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
  async def trial_trojan_(event):
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    await event.edit("`Processing Crate Triall Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1)  + "▱" * ((3 - i) // 1) 
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "${ip} " | /etc/shell/9'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Already Exist**")
    else:
      #today = DT.date.today()
      #later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("trojan://(.*)",a)]
      print(b)
      remarks = re.search("#(.*)",b[0]).group(1)
      domain = re.search("@(.*?):",b[0]).group(1)
      uuid = re.search("trojan://(.*?)@",b[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**     ◇ TRIAL TROJAN ACCOUNT ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Remarks      :** `{remarks}`
**» Host Domain  :** `{DOMAIN}`
**» User ID      :** `{uuid}`
**» Limit IP :** `{ip} IP`
**» port TLS     :** `443`
**» Port NTLS    :** `80`
**» Port GRPC    :** `443`
**» Security     :** `auto`
**» NetWork      :** `(WS) or (gRPC)`
**» Path         :** `/trojan`
**» Path Dynamic :** `http://BUG.COM`
**» ServiceName  :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link TLS   : **
`{b[0]}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link NTLS  :** 
`{b[1].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link GRPC  :** 
`{b[2].replace(" ","")}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Link Account     :**
https://{DOMAIN}:81/trojan-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» Expired Until :** `1 Hour`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trial_trojan_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-tr'))
async def ren_trojan(event):
  async def ren_trojan_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    async with bot.conversation(chat) as pw:
      await event.respond("**Limit Quota :**")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
    async with bot.conversation(chat) as ip:
      await event.respond("**Limit IP :**")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
    async with bot.conversation(chat) as exp:
      await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline("• 7 Day •","7"),
Button.inline("• 15 Day •","15")],
[Button.inline("• 30 Day •","30"),
Button.inline("• 60 Day •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`Processing Update Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1)  + "▱" * ((3 - i) // 1) 
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | /etc/shell/ren trojan'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      x = [x.group() for x in re.finditer("exp://(.*)",a)]
      print(x)
      exp1 = re.search("exp://(.*?)@",x[0]).group(1)
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**  ◇ Succes Renew Trojan Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**» IP :** `{ip}`
**» Expired On :** `{exp1}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_trojan_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)
    
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
  async def delete_trojan_(event):
    async with bot.conversation(chat) as user:
      await event.respond('**Username :**')
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for i in range(4):
        time.sleep(0)  # Ganti dengan durasi yang lebih realistis
        progress = "▰" * (i // 1)  + "▱" * ((3 - i) // 1) 
        await event.edit(f"`Processing... {i}%\n{progress}`")

    await event.edit("`Wait.. Setting up an Account`")
    cmd = f'printf "%s\n" "{user}" | /etc/shell/del trojan'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("**User Not Found**")
    else:
      msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━◇**
** ◇ Succes Delete Trojan Account ◇**
**◇━━━━━━━━━━━━━━━━━━━━━◇**
**» User :** `{user}`
**◇━━━━━━━━━━━━━━━━━━━━━◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹🔹Main Menu🔹›","trojan")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_trojan_(event)
  else:
    await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
  async def trojan_(event):
    inline = [
[Button.inline(" CREATE TROJAN ","create-trojan"),
Button.inline(" TRIAL TROJAN ","trial-trojan")],
[Button.inline(" DELETE TROJAN ","delete-trojan"),
Button.inline(" RENEW TROJAN ","renew-trojan")],
[Button.inline(" CHECK TROJAN ","cek-trojan"),
Button.inline(" LOGIN TROJAN ","login-trojan")],
[Button.inline("‹🔹Main Menu🔹›","menu")]]
    z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
    msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**    🧿 TROJAN MANAGER 🧿**
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Service   :** `TROJAN`
**» Domain   :** `{DOMAIN}`
**» ISP VPS  :** `{z["isp"]}`
**» Country  :** `{z["country"]}`
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await trojan_(event)
  else:
    await event.answer("Access Denied",alert=True)
